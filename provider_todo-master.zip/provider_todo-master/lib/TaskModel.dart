
class TaskModel {
 String title;
 String detail;

 String get getTitle => title;
 String get getDetail => detail;

 TaskModel(this.title, this.detail);

}